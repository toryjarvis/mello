export default {
    API_ENDPOINT:'',
    API_KEY: process.env.REACT_APP_API_KEY,
    TOKEN_KEY: ''
};