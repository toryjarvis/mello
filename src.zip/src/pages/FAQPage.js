import React, { Component } from 'react';

export default class FAQPage extends Component {
     render() {
          return (
               <div className='FAQ-Text'>
                    Under Construction!
               </div>
          )
     }
}