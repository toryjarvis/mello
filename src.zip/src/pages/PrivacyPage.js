import React, { Component } from 'react';

export default class PrivacyPage extends Component {
     render() {
          return (
               <div className='Privacy-Text'>
                    Under Construction!
               </div>
          )
     }
}