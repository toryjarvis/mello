import React, { Component } from 'react';

export default class ContactPage extends Component {
     render() {
          return (
               <div className='Contact-Text'>
                    Under Construction!
               </div>
          )
     }
}